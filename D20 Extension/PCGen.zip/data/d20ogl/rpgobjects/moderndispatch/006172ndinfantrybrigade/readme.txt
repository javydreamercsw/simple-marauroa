To be used with Blood and Guts: Modern Military

-- Frank, 2006.01.21
~~ Auran DnD PCGEN CUSTOMIZATION FILES ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

These files contain the information of Auran d20 products, in PCGEN format.
You can find more information on Auran d20 Products at the official website of Auran d20 : http://www.auran.com/d20

~~ INSTALLATION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Copy the Auran direcory inside the data folder of PCGen.
2. Be sure that the directory structure stays intact.

~~ BUGS/QUESTIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


I'm well aware of the possible bugs in the transformation of the Auran information into PCGen format. Be sure to check
the outcome of PCGen with the Auran books to be sure that you're playing with the correct information. In doubt, know
that the Auran books have always the correct information
Auran, PCGen, nor myself can be made responsible for possible misinformation due to bugs or wrong interpretions in the
PCGen format.
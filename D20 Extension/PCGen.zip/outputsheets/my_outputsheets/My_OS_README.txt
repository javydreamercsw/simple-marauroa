Greetings,

This is an output sheet repository for homebrews to see the many functions of the Output Sheet, both PDf and HTM.

We plan on adding any new features to the OS sheets here.

It is highly advised you make your own homebrew folders here and model your structure to what we use. To avoid losing your changes do not use the same names used here as updating will overwrite the files we provide.


- The PCGen Team
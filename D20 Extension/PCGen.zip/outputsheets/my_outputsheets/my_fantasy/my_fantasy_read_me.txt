Greetings,

This is the model for the fantasy OS stuff. We will be adding things here as we improve the Output sheets.

- The PCGen Team